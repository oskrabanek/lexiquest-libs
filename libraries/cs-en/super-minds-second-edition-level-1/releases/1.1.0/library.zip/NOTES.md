# Editorial notes

This is an unofficial LexiQuest companion, not a Cambridge publication. English vocabulary and unit order were checked against the Cambridge One Super Minds Second Edition Level 1 Student’s Book eBook on 2 November 2026. The Quest set covers Friends (pages 4–9) and Units 1–9 (introductory vocabulary pages 10, 22, 34, 46, 58, 70, 82, 94, and 106). The Friends Quest includes greetings, numbers 1–10, and the six colours shown on page 7; it excludes character names. Czech translations and package metadata were written for LexiQuest.

No textbook page, illustration, cover, or audio is redistributed in this version. The 100 vocabulary illustrations are original LexiQuest assets: 62 reused from the built-in Starter Adventure for the same meanings and 38 newly generated in a matching style. The app uses its generated cover fallback. Audio remains planned.
